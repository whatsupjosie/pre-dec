# Pubcast 2i — Handoff (v10: race-condition fixes, a11y, and three new features on top of v9)

**Date:** August 11, 2026
**File:** `2i_writers_room_v10.html` — built on `2i_writers_room_v9.html`, no visual/layout changes beyond three new menu items. This pass found and fixed three real bugs that only show up under conditions the v9 pass's static read-through couldn't surface (an async request racing a document switch, a discarded file handle, a keyboard trap), then implemented three of the "good fit for another pass" items the v9 handoff explicitly flagged as ready to build: cross-browser autosave, Find & Replace, and manuscript export.

Verified: script block extracted and passed `node --check`; the full HTML markup (everything before `<script>`) has balanced div nesting (checked by depth-tracking every line, not just a raw tag count); every `getElementById` call in the file resolves to a real `id` in the markup (63 references, 76 ids defined, zero misses). Not verified: interactive testing in an actual browser — still no browser in this environment. Please smoke-test before shipping (checklist at the bottom, extended from v9's).

---

## Fixed this pass — real bugs, found by tracing execution paths v9's read-through didn't walk

1. **Opening a document didn't stop what the old one was doing.** `openDocumentForEditing()` swapped `committed`/`buffer`/`pool`/`pointer`/etc. over to the newly-loaded document's data, but never stopped active playback or speech first, and did nothing to invalidate an LLM request that might still be in flight. Concretely: start Play on document A, open document B before A's line finishes reading — the reaction-window timer or speech callback scheduled against A would still fire, call `tick()`, and start auto-advancing *B*'s pool using timing/state left over from A. Worse, if a `generateMoreIntoPool()` or chat `sendChat()` call was in flight when you opened B, its result would land in B's `pool`/`chatHistory` when it resolved, silently mixing two unrelated documents' content together. Fixed with a `docEpoch` counter: bumped on every document load, captured by each async call at the moment it starts, checked again when the call resolves — a stale result is discarded instead of applied. `openDocumentForEditing()` also now calls `stopPlaying()` before swapping state.

2. **Opening a document (via the native Chromium picker) lost the ability to Save back to that same file.** `pickOpenFile()` called `showOpenFilePicker()`, got a writable `handle` back, then discarded it and returned only the plain `File` object. Every subsequent "Save" therefore silently became "Save As" — a fresh file-picker dialog popping up — for the entire rest of the session after opening any document, with zero indication anything had changed about what the Save button does. Fixed: `pickOpenFile()` now returns `{file, handle}`, and `openDocumentForEditing()` passes the handle through so Save writes back in place, exactly like it does after Save As.

3. **The hamburger menu button was invisible to keyboard users.** `menuBtn` is a styled `<div>`, not a `<button>` — it had no `tabindex`, no `role`, and no keydown handler, so it was mouse-only. This also silently broke v9's own claimed fix: v9's Escape handler calls `menuBtn.focus()` to return focus after closing the menu, but `.focus()` on a div with no `tabindex` is a no-op — that "return focus to the trigger" behavior never actually worked for the hamburger menu, only for the (real `<button>`) LLM settings trigger. Fixed: added `tabindex="0"`, `role="button"`, `aria-haspopup`/`aria-expanded`, and an Enter/Space keydown handler, wired through a new `setMenuOpen()` helper so every place that opens/closes the menu keeps `aria-expanded` in sync.

## New this pass — the "good fits" from the v9 handoff's self-assessment

4. **Full keyboard focus trap for the LLM settings modal.** v9 added Escape-to-close and initial/return focus, explicitly noting a full trap was out of scope for that pass. Tab/Shift+Tab now cycle only through the modal's own focusable fields while it's open, instead of walking focus out onto the page underneath. Built as a reusable `trapFocus(modalEl)` helper so the new Find & Replace modal (below) gets the same treatment for free.

5. **Find & Replace** (☰ → Find & replace…). Operates on the draft buffer and the currently-reading line — the same editable surface the pin/regenerate machinery already works on — and deliberately does not touch locked manuscript text, consistent with the app's existing "select a line, then unlock it deliberately" model (the modal copy says this explicitly). Plain substring match; does not re-run structural-edit detection, so it won't trigger a downstream regen — documented in the modal itself so that's not a surprise.

6. **Export manuscript** (☰ → Export manuscript…). Downloads a plain, human-readable `.md` snapshot — committed text grouped by chapter, plus whatever's currently in the draft buffer, clearly marked as still a draft. This is deliberately a different, simpler format than the `.2i` save file: it's for reading or sharing outside the app, not for reopening here.

7. **Cross-browser autosave fallback (IndexedDB-backed).** `showSaveFilePicker`/`showOpenFilePicker` are Chromium-only; Firefox and Safari fall back to plain downloads with no way to write back to the same file, which v9 correctly flagged as a real gap but out of scope for that pass. Every document change now schedules a debounced (2.5s) background snapshot into IndexedDB — best-effort, failures are logged and swallowed rather than surfaced, since autosave breaking shouldn't interrupt anyone's writing. On load, if a snapshot exists, a "Restore autosave…" menu item appears and PubPartner mentions it once in chat with a timestamp. The snapshot is cleared automatically once a real save (in-place, Save As via picker, or plain download) succeeds, so it doesn't linger and offer to "restore" something already safely on disk.

8. **`bufferedProtected`/`.pinned`/"pin" naming unification**, flagged in the v9 handoff as low-risk and worth doing. The JS variable is now `pinnedLines` everywhere (was `bufferedProtected`), matching the CSS class (`.pinned`) and the UI copy ("pin"/📌) it already had to live alongside. The on-disk field is now `pinned`; `openDocumentForEditing()` and `restoreAutosaveSnapshot()` still read the old `bufferedProtected` key as a fallback so documents saved by v9 or earlier restore their pins correctly.

## Also refactored (no behavior change, but worth flagging)

9. **Document-loading logic deduplicated.** `openDocumentForEditing()`'s "take a parsed `.2i` payload and pour it into the working area" logic is now a shared `applyLoadedDocument(data, titleFallback, opts)` function, used by both file-open and the new autosave-restore path. One place to fix instead of two copies that would otherwise drift.

---

## Deliberately not touched this pass either

Still real, still flagged, still bigger than a bug-fix/incremental-feature pass:

- **SSE streaming for LLM replies.** The v9 handoff listed this as a "confident" fit, but implementing it well means changing the fetch/parsing shape of all three provider adapters (Claude, OpenAI, local/Ollama) with no way to click through and confirm the incremental-render behavior actually works smoothly in a browser. Given the choice between shipping an untested streaming implementation across three adapters or shipping the rest of this pass solidly, this pass prioritized the latter. Worth its own pass, ideally with you testing between each provider.
- **Single 1,500+ line file with no state/render/API separation.** Unchanged from v9's assessment — this is still the root cause of the *class* of bug this and the previous pass keep finding instances of (e.g. bug #1 above is exactly the kind of cross-cutting state coupling a real module split would make structurally hard to reintroduce). A real fix is a refactor, not a patch.
- **Undo/redo as a real command stack.** Still flagged by v9 as touching nearly every state-mutating function with no way to verify behavior without a browser — same reasoning applies, unchanged.
- **No true collaboration, no cloud STT fallback for Firefox dictation, plaintext API keys in localStorage, duplicated inline SVG button textures, `id="writeRow"` unreferenced.** Unchanged from v9 — still real, still architecture/roadmap decisions or cosmetic-only, not line-level fixes. See the v9 handoff for the full reasoning on each; it still applies.
- **Full keyboard focus trap for the Find & Replace modal** — actually done this pass (see #4/#5 above, `trapFocus()` is applied to both modals), noting it here only because it's easy to assume it was left at "just the LLM modal" like v9 left it.

---

## Files in this handoff
- `2i_writers_room_v10.html` — the updated file. Open directly in a browser (Chrome/Edge recommended for voice input, in-place Save, and the autosave fallback — though autosave itself is specifically for Firefox/Safari users).
- This file.

---

## Suggested smoke test before shipping

Everything from the v9 checklist still applies (demo-mode fallback, LLM-configured generation continuing correctly from an edit, save/reload round-trip, inline unlock, spine resize, Skip during playback, Escape closing the modal/menu). Additionally for this pass:

1. **Open document mid-playback:** start Play on one document, open a different `.2i` file before the current line finishes reading — confirm playback actually stops and the new document doesn't start auto-advancing on its own.
2. **Save after Open (Chrome/Edge):** open a `.2i` file via the native picker, make an edit, click Save — confirm it writes back to the *same* file with no picker dialog popping up (previously this always fell through to Save As after any Open).
3. **Keyboard-only menu:** Tab to the hamburger menu button, confirm it visibly focuses, press Enter or Space — confirm the menu opens. Press Escape — confirm it closes and focus visibly returns to the hamburger button.
4. **Tab out of the LLM modal:** open ⚙ LLM provider…, Tab repeatedly — confirm focus cycles within the modal's fields/buttons and never lands on something behind it on the page. Same test for Find & Replace.
5. **Find & Replace:** add a few lines to the draft buffer with a repeated word, ☰ → Find & replace…, replace it — confirm the buffer updates and the match count is accurate. Confirm locked/committed text is untouched.
6. **Export:** ☰ → Export manuscript… — confirm a `.md` file downloads with chapter headers and readable text.
7. **Autosave (test in Firefox or Safari for the realistic case):** write a few lines, wait ~3 seconds without saving, close the tab without saving, reopen the app — confirm a "Restore autosave…" option appears in the menu and PubPartner mentions it in chat, and that restoring it brings the content back.
8. **Autosave clears on real save:** after restoring an autosave (or just writing fresh content), do a proper Save — confirm the "Restore autosave…" menu item's underlying snapshot is gone (reload the page; it shouldn't reappear).
9. **Old save files still load:** if you have a `.2i` file saved by v8 or v9, confirm it still opens correctly and pinned lines (if any) still show as pinned, despite the on-disk field name changing from `bufferedProtected` to `pinned`.
