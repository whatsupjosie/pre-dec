# Bubble Stack — Planned Use, Intended Use, Execution, and Current Integration

Prepared from the available Rear View Foresight / PubCast project materials in the ChatGPT file library.

## What is included

1. **01_PLANNED_USE.md** — the architectural/planning context: where Bubble Stack belongs in PubCast and how it relates to the studio, The View, 2i, and the wider system.
2. **02_INTENDED_USE.md** — the intended runtime role: Bubble Stack as room-local spatial awareness/context, not a character slot and not a replacement for Jeremy, Room Conductor, memory, cameras, or recording.
3. **03_ACTUAL_EXECUTION_CODE.md** — the actual Bubble Stack implementation preserved in the Aug. 10 handoff, including the adapter, routes, BubbleStat schema, state machine, PIKPC promotion bridge, and engine-facing behavior.
4. **04_CURRENT_USAGE_AND_INTEGRATION.md** — how the current PubCast host wires and uses Bubble Stack, including Room Conductor/Jeremy integration and regression tests.
5. **05_TRACEABILITY.md** — source map and notes distinguishing documented facts from architectural interpretation.
6. **source_documents/** — the original source documents from which this dossier was assembled.

## Important distinction

The available material contains a substantial implementation record for Bubble Stack. It also contains the broader 2i / The View design context. The original conversational/UI conception of Bubble Stack is less completely preserved than the implementation record, so this dossier does not invent missing details. Where the source supports only an architectural inference, that is labeled as such.
