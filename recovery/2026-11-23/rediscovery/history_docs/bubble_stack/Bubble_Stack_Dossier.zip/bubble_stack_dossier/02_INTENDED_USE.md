# 02 — Intended Runtime Use

## Core idea

A Bubble Stack divides a room into spatial regions (“bubbles”) and tracks presence within those regions. An actor's bones and objects can be associated with bubbles; the stack can then derive a compact description of the room.

The safe PubCast-facing state machine is:

- **UNCONFIGURED** — no room geometry exists.
- **CONFIGURED** — geometry exists, but no AI has entered.
- **SLEEPING** — geometry exists and no AI is present.
- **ACTIVE** — AI is present and BubbleStat updates matter.
- **AI_BLIND** — spatial awareness cannot be trusted for the room.

The explicit AI_BLIND behavior is important: an absent or broken Bubble Stack must not make the room crash or falsely claim spatial awareness.

## How information flows

1. A room is configured with an origin, dimensions, bubble radius, and spacing.
2. The adapter generates the room's bubble grid.
3. AI presence can be declared for actors in that room.
4. Skeleton frames can be ingested; the SkeletonTracker classifies posture and converts bones to Bubble Stack presence records.
5. Objects can also be ingested and associated with spatial bubbles.
6. Active bubbles are summarized into BubbleStat.
7. The summary can be exposed through API routes or formatted as a short context string for Jeremy / Room Conductor.
8. If PIKPC v1.6 is available, the adapter promotes the mature engine behind the stable public interface.
9. If PIKPC fails, the safe v0.1 path remains available.

## Why Jeremy consumes it

The BubbleJeremyAdapter is deliberately described as a “small adapter from Bubble Stack spatial summaries to Jeremy-safe shoulder prompts.” It formats facts such as state, active/total bubbles, actors, postures, nearby relationships, PIKPC activity, recent order events, performance continuity, and recent meaningful events.

That makes Bubble Stack a **perception/context provider** while Jeremy remains the conductor.

The Room Conductor wiring explicitly describes the Bubble Stack provider as optional, read-only context. It also explicitly says Room Conductor is process infrastructure, not a character slot.

## Physical/consequence side

The PIKPC sandbox goes further than simple occupancy. Its documented sandbox actions include walking to a table, activating a cup hotspot, picking up a cup, drinking, setting it down, slamming it down, pushing it away, and throwing it. Its outcomes include objects hitting tables, vases, chairs, floors, and walls, plus vase/table/chair movement and damage states.

This indicates a second intended use for the underlying PIKPC system: **spatial/physical consequence reasoning** in simulated environments. The current PubCast adapter, however, keeps that engine behind a safe context interface rather than making it the entire studio runtime.
