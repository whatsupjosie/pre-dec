# REARVIEW FORESIGHT / PUBCAST
## PRESERVATION HANDOFF — GATED FOR TODAY
### 2026-08-10
### Source snapshot: `PubPartner_Horizon_v0.1.0-prebeta.12.zip`

**Purpose:** Preserve the architecture, terminology, product boundaries, hard-won implementation decisions, and the next direction so another AI can continue the work without flattening or accidentally undoing what has already been built.

**Status of this handoff:** TODAY-GATED / PRESERVATION BASELINE  
This is the context to preserve before making new architectural changes.

---

# 0. THE MOST IMPORTANT CORRECTION

## Rearview Foresight is the company.

It is **not** the name of the architecture, the UI, or the main application.

The current hierarchy is:

```text
REARVIEW FORESIGHT
      │
      │  COMPANY
      ▼
   PUBCAST
      │
      │  PRINCIPAL PROGRAM / CREATIVE PLATFORM
      ▼
   THE VIEW
      │
      │  OVERALL OPERATING ENVIRONMENT / OS SHELL
      │
      ├── PubCast rooms / production environments
      ├── PubPartner
      ├── Iteration Wallet
      ├── BlackBox
      ├── 2i
      └── future programs / capabilities
```

The individual programs should remain independently valuable and, where appropriate, independently deployable.

---

# 1. THE VIEW

The overall UI/OS is currently being conceptualized as:

# THE VIEW

The name is intentionally related to **Rearview Foresight**.

The View is not simply "the PubCast UI."

It is the **overall operating environment through which the user moves among the different programs, rooms, trays, tools, and contexts.**

Each major program can have its own:

- UI
- menu system
- commands
- trays
- workspace state
- specialized context

But The View provides the coherent environment that lets the user move between them naturally.

The user's metaphor:

> The user is at the counter. The different programs/rooms are like trays on the counter. You move between them rather than feeling like you are launching unrelated applications.

The View should therefore feel like an operating environment rather than a collection of disconnected web pages.

The View does not necessarily own the domain behavior of every product.

It provides the shared experience, navigation/composition, and context in which independent programs can cooperate.

---

# 2. THE COUNTER / ROOM MODEL

The "counter" is a useful UX metaphor:

- The user stands at the counter.
- Each tray has a reason to exist.
- Each room/location provides a distinct capability or context.
- Moving between trays should be easy.
- A program can maintain its own specialized UI while remaining native to the overall environment.

Important principle:

> A room earns its existence by giving the user a distinct reason to enter it.

The project is already far enough along that many rooms have their own programs. That is not automatically a problem. In this architecture, a room can represent a meaningful workflow boundary.

Do not flatten rooms simply because they are numerous.

At the same time, do not create a room that merely duplicates another room with different decoration.

---

# 3. 2i — NEW IMPORTANT NAME

The strongest new result from the current conversation is:

# PubCast 2i
## The Writer's Room

**2i** replaces the temporary working name **CoLab Editor**.

The user explicitly clarified that this is **not merely a word processor**.

It is the **Writer's Room**: the collaborative creative environment where the human creator and AI work together on the creative material.

The meaning of **2i** is intentionally layered:

- Two intelligences
- AI + I
- Two perspectives
- Two eyes on the work
- Teamwork
- Collaboration

The phrase "two eyes on the project" is part of the conceptual identity.

The core idea:

> Two intelligences working together on the same creative object.

The Writer's Room can encompass:

- story development
- brainstorming
- scene development
- dialogue
- character development
- continuity
- revision
- critique
- research
- planning
- creative decisions
- collaborative writing

It should not be reduced to a conventional word processor.

### Important distinction

**2i** is the collaborative human+AI room.

**PubPartner** is the personality/character platform.

Those are not the same thing.

2i is where the human and AI collaborate.

PubPartner is where persistent characters/personas can exist and be managed.

---

# 4. PRODUCT FAMILY

Current intended product family:

```text
REARVIEW FORESIGHT
      │
      ▼
    PUBCAST
      │
      ├── 2i
      │    └── Writer's Room / human + AI collaboration
      │
      ├── PubPartner
      │    └── persistent AI personalities / characters / memory / relationships
      │
      ├── Iteration Wallet
      │    └── iteration / provenance / creative resources / lineage
      │
      └── BlackBox
           └── independent capability product
```

There is also a production/orchestration concept currently called **Pub Manager**, which should remain a distinct capability/product boundary unless the code proves otherwise.

---

# 5. PRODUCT INDEPENDENCE

This is the most important architectural principle.

```text
                 INDEPENDENT VALUE
                        │
          ┌─────────────┼─────────────┐
          ▼             ▼             ▼
      PubPartner   Iteration Wallet  BlackBox
          │             │             │
          └─────────────┼─────────────┘
                        │
                     + PubCast
                        │
                        ▼
                COMBINED VALUE
                        │
                        ▼
             GREATER THAN THE SUM
                OF THE PARTS
```

The products should be independently useful.

Integration should create additional value rather than merely satisfying dependencies.

### Bad

```text
PubCast
  ↓
PubPartner
  ↓
Iteration Wallet
  ↓
BlackBox
```

### Desired

```text
PubPartner ─────┐
                │
Iteration ──────┼──→ OPTIONAL BRIDGES → PubCast
Wallet          │
                │
BlackBox ───────┘
```

The correct relationship is:

> PubCast knows how to speak to PubPartner.

Not:

> PubPartner belongs to PubCast.

A product should be removable, replaceable, or usable elsewhere without collapsing unrelated products.

---

# 6. PUBCAST

PubCast is the principal creative/production program.

It is the studio environment for:

- filmmaking
- directing
- staging
- scenes
- avatars
- performers
- camera work
- recording
- production
- voxel/world environments
- choreography
- rendering
- asset use
- export
- production workflows

The current code snapshot confirms that the full PubCast host remains available in `main.py`, while the lightweight PubPartner launcher deliberately does not start the full studio stack.

That separation is good and should be preserved.

The current capability map explicitly identifies the full host as retaining:

- RoomConductor
- Bubble Stack
- e-PETE
- camera
- recording
- avatar/choreography
- voxel renderer

These are retained but not started by the lightweight canonical PubPartner launcher.

---

# 7. PUBPARTNER

PubPartner is the persistent personality/character platform.

Core concepts:

- personality
- character identity
- persistent memory
- relationships
- continuity
- source/evidence-aware memory
- provider-neutral model boundary
- assistance
- character development
- contextual behavior

Characters discussed historically include:

- Alex
- Jeremy
- Pete
- RePete
- Sir Purfluous
- Marla
- Bartender
- other future personalities

PubPartner must be able to exist without PubCast.

Example:

```text
PubPartner
    ↓
Pete
    ↓
conversation
    ↓
memory
    ↓
relationship
```

No studio is required for that to be a legitimate product.

---

# 8. CURRENT PUBPARTNER SNAPSHOT — WHAT IS ACTUALLY PRESENT

The uploaded snapshot contains **394 files**.

The current package identifies `pubpartner_app.py` as the canonical lightweight/default runtime.

The documented boot path is:

```text
run_pubpartner launcher
    ↓
preflight / persistent local security
    ↓
uvicorn pubpartner_app:app
    ↓
auth/user database
    ↓
Governance
    ↓
Pub Manager authority/policy
    ↓
Alex/Jeremy bridge
    ↓
Alex core
    ↓
optional Cricket continuity
    ↓
PubPartner vessel
    ↓
PubPartner spine
    ↓
provider-neutralized friend loop
```

The package documentation reports:

- 187 passing tests
- 3 skipped live-provider tests
- fresh preflight OK
- restart probe verified
- control-plane probe verified
- 90 live routes
- no duplicate method/path pairs

The skipped tests are live-provider/Ollama-related, not reported as regressions.

---

# 9. PUBPARTNER VESSEL / CUSTODY

The current package includes a **PubPartner Vessel v1** foundation.

It is described as a single-file, model-independent authority for:

- Alex identity
- relationships
- evidence-governed memory
- scoped context
- embedded asset bindings
- integrity
- backup
- correction

The vessel is a major thing to preserve.

Do not casually replace it with a new memory system.

The package's stated design philosophy is custody and reproducibility.

---

# 10. PROVIDER NEUTRALITY

Preserve the provider-neutral boundary.

Current implementation includes:

- provider registry
- provider neutralizer
- OpenAI-compatible provider support
- Ollama provider
- mock/offline path

The architectural principle is:

> The model is a replaceable cognitive service.

The model should not own:

- canonical identity
- canonical event history
- relationship authority
- permissions
- provenance
- custody

This is one of the strongest architectural decisions in the current code.

---

# 11. MEMORY / RELATIONSHIP ARCHITECTURE

Previous generations contain several useful memory/relationship systems.

Do not activate multiple competing authorities.

Current reconciliation guidance says:

### PRESERVE

- PubPartner Spine
- source provenance
- receipts
- RelationshipEngine
- UniversalMemorySystem as a memory-bank contract
- Jeremy Cricket / CricketKeeper
- RoomConductor
- ThoughtLogger
- NudgeCalibration
- old NudgeQueue/NudgeConsumer as compatibility boundary

### REFACTOR

Multiple memory authorities.

Multiple orchestrators.

The goal is:

> One canonical contract with adapters around historical implementations.

Do not discard useful donor implementations blindly.

Do not let duplicate systems become competing authorities.

---

# 12. EVENT AGENCY — CURRENT HORIZON

The August 9, 2026 Horizon work added the first persistent event-agency seam.

Current components include:

- typed Event
- append-only EventLedger
- nudge lifecycle recording
- event observation layer

The latest conceptual distinction is extremely important:

> An event occurring is not the same thing as a character noticing it.

Current observation/salience scoring uses deterministic, inspectable factors including:

- event priority
- confidence
- recency
- relationship salience
- context salience

The current deliberate non-features are:

- no autonomous action
- no model-generated authoritative state
- no automatic intention creation
- no permission bypass
- no replacement of existing memory/relationship engines

The current direction is:

```text
EVENT
  ↓
OBSERVATION
  ↓
ATTENTION
  ↓
INTENTION
  ↓
DELIBERATION
  ↓
PERMISSION
  ↓
ACTION
  ↓
CONSEQUENCE EVENT
  ↓
MEMORY / RELATIONSHIP EVIDENCE
```

The immediate next technical horizon is **Attention**, not autonomous agency.

First make it possible to answer durably:

- What happened?
- Who was exposed to it?
- Who noticed it?
- How salient was it?
- Why was it salient?
- What evidence produced the score?
- Was it ignored, deferred, or retained?

Only then should persistent intentions be introduced.

---

# 13. AUTHORITY / GOVERNANCE

The current system has unusually important authority boundaries.

Preserve them.

Permanent bans, kicks, destructive deletion, and other irreversible/punitive actions remain human-required.

Eligible reversible containment may be automatically approved only when:

- deterministic evidence policy permits it
- duration is bounded
- authority is action/target/session bound
- the grant expires
- the grant is one-use
- the required BlackBox evidence is recorded

The client cannot supply a trusted authority packet.

Replay after consumption is rejected.

Failure to record required BlackBox evidence blocks executable approval.

This is not incidental plumbing. It is part of the architecture.

---

# 14. BLACKBOX

Terminology has historically varied between **BlackBox** and **BlackBot**.

Do not silently merge these names without examining the current implementation.

The current capability map explicitly identifies a **BlackBox audit / persisted authority record** path.

Historically BlackBot was discussed as automation/assistant capability.

BlackBox has been discussed as an independent capability product.

Resolve whether:

1. BlackBot and BlackBox are the same evolving product,
2. BlackBot is a component/service of BlackBox,
3. or they are separate.

Until verified, preserve the distinction.

---

# 15. ITERATION WALLET

Iteration Wallet is intended to remain independent.

Conceptual scope includes:

- iteration
- provenance
- creative history
- version/state
- resources
- lineage
- permissions/custody where appropriate

The current UI transplant handoff explicitly states that the **Frozen Iteration Wallet remained unchanged**.

No Wallet custody, passkey, LabCopy, Candidate/Prime promotion, Oubliette, identity, or storage namespace behavior was imported into the PubPartner UI transplant.

That is a critical boundary to preserve.

PubCast may consume Iteration Wallet.

PubPartner may potentially consume it.

Other applications may consume it.

It must not silently become PubCast's internal database.

---

# 16. OUBLIETTE

Historical security architecture includes:

- protected resources
- permission files
- keys
- human verification
- randomized verification prompts
- protected iteration/custody concepts

Earlier discussion corrected the permission-file count to **four**.

Human-presence checks discussed included:

- blink
- smile
- wink
- head left/right
- randomized prompts

There has also been discussion of Iteration Wallet and Oubliette relationships.

Do not declare these production-grade security merely because they exist.

Treat the current implementation as something to audit against an explicit threat model.

---

# 17. CURRENT UI ARCHITECTURE — IMPORTANT

The current `UI_ARCHITECTURE_STANDALONE_EMBEDDED.md` is unusually aligned with the emerging View concept.

It states:

- `pubpartner.html`
- `pubpartner.css`
- `pubpartner.js`

create the full PubPartner shell.

`WorkspaceRuntime` owns only presentation state:

- tray geometry
- z-order
- collapse
- material
- theme
- motion preference
- local layout import/export

`CommandRegistry` maps visible controls to existing PubPartner behavior.

The UI does **not** own:

- companion identity
- governed memory
- evidence
- custody
- provider secrets
- authorization

Those remain behind authenticated backend routes/modules.

Most importantly, the existing architecture already anticipates:

### Standalone mode

PubPartner creates:

- top bar
- menus
- tray field
- theme state
- workspace persistence

### Embedded mode

PubPartner registers:

- trays
- commands

with a host-provided shell **without creating**:

- a second top bar
- a second theme manager
- a second persistence namespace
- a second window manager

The document explicitly says:

> PubCast may own top-level composition while PubPartner continues to own its domain trays and command implementations.

This is extremely close to the intended **The View** architecture.

Do not throw this away.

---

# 18. UI TRANSPLANT RESULTS

The prior UI release handoff reported:

- 10 trays
- 8 menus
- 34 command controls
- correct Media and Memory routing
- theme switching
- versioned save
- corrupt-layout recovery
- zero console errors
- zero page errors
- real lightweight server boot
- `/pubpartner` returned HTTP 200

The exact test count in that earlier UI snapshot was 180 passed / 3 skipped.

The later August 9 Horizon snapshot reports 187 passed / 3 skipped.

Treat the **latest uploaded snapshot as authoritative for current test status**, and older counts as historical evidence.

---

# 19. EXISTING PUBCAST / AVATAR ARCHITECTURE TO PRESERVE

Historical PubCast work included:

### Performer Entity Layer

Character/performer identity separate from visible mesh.

### PubCast Universal Rig (PUR)

Universal skeleton/animation foundation.

### Canonical Core Skeleton

Shared core.

### Anatomical Extension System

Examples:

- TailModule
- WingModule
- ExtraArmModule
- DigitigradeModule

### Morphology Adapter Layer

Maps different anatomies to the common rig.

### Skin / Costume Layer

Separates appearance from character logic.

### Animation Runtime

Common animation execution.

### EVO / Nervous System

Emotional/behavioral layer.

### Motion Translation Layer

Maps motion between systems.

Historical goal:

> All 35 animations should work on any compatible avatar.

Other previously discussed systems:

- GLB humanoid renderer
- Motion-compatible skeleton
- procedural pipeline
- morph-target identity system
- Ethereal Shader Layer
- voxel engine
- camera systems
- recording
- choreography
- export
- re-skinning

Preserve these behind interfaces.

Do not burden the lightweight PubPartner runtime with them.

---

# 20. EVO / NERVOUS SYSTEM

Historical endpoint pattern:

`/api/nervous-system/{avatar_id}/emotion`

Conceptual flow:

```text
Input / Perception
      ↓
Emotional Cue Interpretation
      ↓
EVO / Nervous System
      ↓
Character / Personality State
      ↓
Behavior / Expression
      ↓
Avatar / Performance
```

Treat this as an evolving subsystem, not a reason to merge all character cognition into PubCast.

---

# 21. 2i'S RELATIONSHIP TO THE OTHER PRODUCTS

The current conceptual map is:

```text
2i
  = HUMAN + AI COLLABORATION
  = THE WRITER'S ROOM

PubPartner
  = PERSISTENT PERSONALITIES / CHARACTERS

Iteration Wallet
  = ITERATION / PROVENANCE / CREATIVE LINEAGE

BlackBox
  = INDEPENDENT SPECIALIZED CAPABILITY

PubCast
  = PRODUCTION / STUDIO / CREATION ENVIRONMENT

The View
  = OVERALL OS / ENVIRONMENT / COMPOSITION SHELL
```

2i can interact with PubPartner.

2i can create or modify material that is tracked by Iteration Wallet.

2i can call BlackBox capabilities.

2i can hand developed material toward PubCast production.

None of those relationships should automatically become hard dependencies.

---

# 22. HUMAN + AI MODEL

The user is the creator/director/decision-maker.

The conversational AI is not simply "another PubPartner character."

The distinction is:

### 2i

Human + AI collaborative intelligence.

### PubPartner

Persistent character/personality system.

The View is the environment in which the human and AI can work across the various products.

The intended experience is not:

> "Launch chatbot."

It is:

> "Stand at the counter with the AI and work across the creative environment."

The AI should be able to help:

- navigate
- reason
- write
- design
- critique
- troubleshoot
- orchestrate
- move between rooms
- invoke capabilities
- understand context

without becoming the owner of every underlying subsystem.

---

# 23. ARCHITECTURAL LAYERS

The cleanest current model is:

```text
REARVIEW FORESIGHT
        │
     COMPANY
        │
        ▼
     PUBCAST
        │
        ▼
    THE VIEW
  OVERALL OS / SHELL
        │
        ▼
 PROTOCOLS / CONTRACTS
        │
   ┌────┼──────────────┐
   │    │              │
   ▼    ▼              ▼
  2i  PubPartner   Iteration Wallet
   │    │              │
   └────┼──────────────┘
        │
     BlackBox
        │
    Pub Manager
        │
   Shared services
```

But product independence remains the rule.

---

# 24. CONTRACTS TO EVENTUALLY FORMALIZE

Potential capability contracts:

- Identity
- Personality
- Memory
- Relationship
- Iteration
- Provenance
- Resource
- Asset
- Event
- Observation
- Attention
- Permission
- Capability
- Project
- Production
- Command
- Workspace

Start with the smallest useful contracts.

Do not design a giant API universe before auditing the actual code.

---

# 25. ARCHITECTURAL TESTS TO ADD

Eventually make the independence philosophy executable.

Examples:

```text
PubPartner boots without PubCast.

Iteration Wallet operates without PubCast.

BlackBox operates without PubCast.

2i can operate without full studio systems.

PubCast can operate when optional products are absent.

PubCast cannot import PubPartner's internal database directly.

PubCast communicates with PubPartner through published contracts.

A mock PubPartner can replace the real one.

A mock Iteration Wallet can replace the real one.

Product contract version changes do not require internal rewrites.

Removing one optional product does not collapse unrelated products.
```

Also test:

```text
Standalone shell
vs.
Embedded shell
```

The embedded mode must not create duplicate:

- top bars
- theme managers
- persistence namespaces
- window managers

---

# 26. CURRENT GENERATIONAL LESSONS

The reconciliation report identifies three generations.

### Generation 1 — May

Compact behavioral core:

```text
input
 ↓
score
 ↓
state transition
 ↓
nudge
 ↓
orchestrator
 ↓
model
```

Preserve:

- explicit state transitions
- measurable signals
- queue boundary
- persona permissions
- full-pipeline tests

### Generation 2 — July

Solved:

- authority
- persistence
- provider boundaries
- source custody
- relationship continuity
- restart behavior
- lightweight/full-host coexistence

Weakness:

> capability density

Do not respond by adding more features blindly.

### Generation 3 — August

Adds durable event agency:

- Event
- EventLedger
- observation
- deterministic salience

Direction:

> unification, not multiplication.

---

# 27. TARGET AGENCY ARCHITECTURE

The preferred long-term nervous-system architecture is:

```text
WORLD / USER / SYSTEM EVENTS
            │
            ▼
      CANONICAL EVENT LEDGER
            │
            ▼
       OBSERVATION LAYER
            │
            ▼
        ATTENTION LAYER
            │
            ▼
       CHARACTER STATE
            │
            ▼
       INTENTION STORE
            │
            ▼
      DELIBERATION / POLICY
            │
            ▼
       PERMISSION GATE
            │
            ▼
           ACTION
            │
            ▼
       CONSEQUENCE EVENT
            │
            └──────────────► MEMORY / RELATIONSHIP EVIDENCE
```

The model belongs inside deliberation/generation as a replaceable cognitive service.

It should not own canonical state.

---

# 28. WHAT NOT TO DO

Do not:

- turn PubCast into a monolith
- make PubPartner require PubCast
- make Iteration Wallet a PubCast database
- make BlackBox secretly dependent on PubCast
- merge 2i into a generic text editor
- replace the existing vessel with a new memory system without evidence
- activate competing memory authorities
- activate duplicate orchestrators
- blindly merge donor implementations
- treat model output as authoritative state
- bypass permission/governance boundaries
- assume historical documentation equals current implementation
- rewrite working systems merely to make the architecture look cleaner
- remove rooms simply because there are many
- create rooms that have no unique purpose

---

# 29. WHAT TO DO NEXT

The next AI should work from the uploaded snapshot rather than inventing another abstract architecture.

Priority:

## 1. Map the actual current UI

Identify:

- global shell
- WorkspaceRuntime
- CommandRegistry
- trays
- menus
- room routing
- persistence
- embedded seams

Then determine how close the existing shell already is to **The View**.

## 2. Map actual product boundaries

Determine from imports/routes/storage:

- what is truly PubPartner
- what is truly PubCast
- what is Wallet
- what is BlackBox
- what is Pub Manager
- what should become 2i

## 3. Build current-vs-target architecture

```text
CURRENT CODE
     ↓
AUDIT
     ↓
HEALTHY BOUNDARIES
     ↓
ACCIDENTAL COUPLING
     ↓
TARGET
     ↓
MINIMUM EXTRACTION PLAN
```

## 4. Identify the smallest contract seams

Do not refactor everything at once.

## 5. Preserve the working runtime

The latest verified pre-beta snapshot is a foundation, not disposable scaffolding.

---

# 30. THE DEEPER PRODUCT MODEL

The product family is not intended to be:

> one application split into artificial modules.

It is:

> independent creative products that become dramatically more powerful when they cooperate.

The equation is:

```text
INDEPENDENT VALUE
       +
OPTIONAL INTEGRATION
       ↓
COMBINED VALUE
       ↓
GREATER THAN THE SUM
OF THE PARTS
```

The customer can buy one.

They can use two.

They can eventually use all of them.

The ecosystem becomes more valuable without making individual products worthless outside it.

---

# 31. THE VIEW / COUNTER / ROOMS

The View should make the whole thing feel coherent.

The user should be able to move:

```text
Writer's Room
     ↓
Character / PubPartner
     ↓
Iteration / provenance
     ↓
BlackBox capability
     ↓
Studio / PubCast
```

without feeling like they have left one unrelated application and launched another.

The rooms remain distinct because the **context and capability are distinct**.

The View is what makes those distinct places feel like one environment.

---

# 32. THE NAME STACK — CURRENT

## Company

**REARVIEW FORESIGHT**

## Main program

**PUBCAST**

## Overall OS / UI environment

**THE VIEW**

## Writer's Room

**PUBCAST 2i**

## Persistent personality platform

**PUBPARTNER**

## Iteration/provenance system

**ITERATION WALLET**

## Independent capability

**BLACKBOX**

## Production/orchestration

**PUB MANAGER**

## Former working name

**CoLab Editor** — retired/replaced by **2i**.

---

# 33. 2i — PRESERVE THIS IDEA

The user explicitly identified the strongest new name from this conversation as **2i**.

Do not lose the meaning.

```text
2i
│
├── Two Intelligences
├── AI + I
├── Two Eyes
├── Two Perspectives
├── Teamwork
└── Collaboration
```

The product is:

# PubCast 2i
## The Writer's Room

The room is where human and AI work together.

That is the intended identity.

---

# 34. THE BIG PICTURE

The system is moving toward:

```text
                   REARVIEW FORESIGHT
                        COMPANY
                           │
                           ▼
                        PUBCAST
                           │
                           ▼
                        THE VIEW
                    CREATIVE OS / SHELL
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
       2i             PubPartner       Iteration Wallet
  Writer's Room       Personality        Provenance
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                        BlackBox
                           │
                      Pub Manager
                           │
                           ▼
                    Production / World
```

But the dependency graph remains intentionally loose:

```text
PRODUCTS AT THE EDGES
        ↓
CONTRACTS IN THE MIDDLE
        ↓
SHARED INFRASTRUCTURE BELOW
        ↓
THE VIEW ABOVE / AROUND THEM
        ↓
HUMAN + AI AT THE CENTER
```

The user is not the component being orchestrated.

The user is the creator.

The system exists to increase what the creator can see, make, remember, revise, coordinate, and produce.

---

# 35. FINAL PRESERVATION RULE

If a future AI is unsure whether to replace an existing subsystem, ask:

> **What problem does the existing thing already solve?**

Then:

> **Is there evidence that it fails?**

Then:

> **Can we put a clean contract around it instead of replacing it?**

Then:

> **Would replacing it destroy hard-won behavior, provenance, custody, or continuity?**

The project has already passed the point where a clean rewrite is automatically better.

The goal now is **controlled convergence**.

Preserve proven behavior.

Extract boundaries.

Unify contracts.

Remove accidental coupling.

Add new capability only where it creates real value.

---

# 36. TODAY-GATED CONTINUATION STATEMENT

As of **August 10, 2026**, the preservation baseline is:

**Rearview Foresight** = company.

**PubCast** = principal program / creative platform.

**The View** = overall operating environment / OS shell.

**2i** = PubCast's Writer's Room; human + AI collaborative creation.

**PubPartner** = independent persistent personality/character platform.

**Iteration Wallet** = independent iteration/provenance/creative lineage system.

**BlackBox** = independent specialized capability; terminology with BlackBot remains to be resolved from code.

**Pub Manager** = production/orchestration boundary.

The uploaded `PubPartner_Horizon_v0.1.0-prebeta.12.zip` is the current evidence base.

The most important existing architectural seam to preserve is the **standalone/embedded UI boundary**: PubPartner can provide its own shell or register its trays/commands with a host shell without duplicating global UI infrastructure.

The most important emerging cognitive seam to preserve is:

```text
EVENT
→ OBSERVATION
→ ATTENTION
→ INTENTION
→ DELIBERATION
→ PERMISSION
→ ACTION
```

The most important product principle to preserve is:

> **Independent value first. Integration second.**

The most important new name to preserve is:

# **2i**
### **PubCast's Writer's Room**
### **Two Intelligences. Two Eyes on the Work.**

And the most important architectural ambition is:

> **Build a coherent creative operating environment without turning the independent products inside it into a monolith.**

---

## HANDOFF END

**GATED DATE:** 2026-08-10  
**SOURCE:** `PubPartner_Horizon_v0.1.0-prebeta.12.zip`  
**PURPOSE:** Preserve context before further architectural evolution.
