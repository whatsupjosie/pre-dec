# 01 — Planned Use

## Bubble Stack in the PubCast architecture

The preservation handoff places Bubble Stack inside **PubCast**, the principal creative/production program. PubCast is described as the studio environment for filmmaking, directing, staging, scenes, avatars, performers, cameras, recording, voxel/world environments, choreography, rendering, assets, and production workflows.

The capability map explicitly retains **RoomConductor, Bubble Stack, e-PETE, camera, recording, avatar/choreography, and the voxel renderer** in the full PubCast host.

The same architecture separates PubPartner from PubCast: PubPartner is the persistent personality/character platform and must be usable without PubCast. This means Bubble Stack is not supposed to become a personality or memory system merely because characters can consume its information.

## Planned conceptual role

The implementation record makes the planned role clear enough to state precisely:

> Bubble Stack is a **spatial-awareness layer for a room**.

Its job is to turn spatial/perceptual state into a stable, consumable room summary. That summary can then be supplied to higher-level systems that need to know what is happening in the environment.

The public schema is centered on:

- room identity
- room state
- AI presence
- number of bubbles
- active bubbles
- actors seen
- postures
- who is nearby whom
- meaningful events
- engine version
- engine summary

This is fundamentally different from a character's personality, memory, or dialogue engine.

## Relation to the larger environment

The broader project names **The View** as the overall creative OS / shell and **PubCast 2i** as the Writer's Room. The source material describes The View as what makes distinct places feel like one environment. That is useful context for Bubble Stack, but the available record does not establish that Bubble Stack itself is the UI representation of The View.

The defensible architectural interpretation is therefore:

**The View / PubCast** → environments and production systems → **Bubble Stack** → spatial facts/context → **Jeremy / Room Conductor / other consumers**.

## What was explicitly not intended

The code documentation explicitly says Bubble Stack does **not** replace:

- Jeremy
- Room Conductor
- Session Runtime
- e-PETE
- memory
- recording
- cameras

It is an adapter/context layer around those systems, not a competing orchestration or identity system.
