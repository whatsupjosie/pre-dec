# 04 — Current Usage and Integration

## Host boot integration

The current PubCast host has an explicit Bubble Stack boot stage described as **“Bubble Stack spatial awareness routes.”** When the Bubble Stack module is available, the application includes its router at `/api/bubble-stack`.

The host also creates a BubbleJeremyAdapter when the summary provider is available and stores it on application state.

Room Conductor is then created separately. If Bubble Stack is available, Room Conductor receives `get_bubble_summary` through `set_bubble_summary_provider`.

The log message in the source is explicit: **“Room Conductor wired — optional Bubble context, no character slot.”**

## Current API surface

The preserved route layer provides:

- `GET /api/bubble-stack` — list configured rooms without creating/waking them.
- `GET /api/bubble-stack/schema` — stable BubbleStat schema.
- `POST /api/bubble-stack/{room_id}/configure` — configure a room's geometry.
- `POST /api/bubble-stack/{room_id}/ai-presence` — declare AI actors present.
- `POST /api/bubble-stack/{room_id}/skeleton-frame` — ingest skeleton data and classify posture.
- `GET /api/bubble-stack/{room_id}/status` — room status / BubbleStat summary.
- `POST /api/bubble-stack/{room_id}/sleep` — clear AI presence and put a configured stack to sleep.
- `GET /api/bubble-stack/{room_id}/stat` — BubbleStat summary.
- `GET /api/bubble-stack/{room_id}/ai-context` — world state plus conversation/event/Jeremy context.

## Current execution model

The adapter maintains a stable v0.1-shaped public interface while optionally promoting **PIKPC v1.6** behind it.

The promotion bridge initializes `BubbleStackEngine` using a root bubble size derived from room spacing/radius. When AI is not present, the kinetic PIKPC runtime does not step; it retains cached frame objects. When the room is ACTIVE and AI is present, skeleton/object updates can step the engine.

The adapter reports the engine as `v1.6-pikpc` when active and `v0.1-safe` otherwise.

## Current tests / evidence of use

The preservation handoff includes regression tests verifying:

- `/api/bubble-stack/schema` still responds.
- Configuring a test room yields `CONFIGURED`.
- Adding AI presence yields `ACTIVE`.
- The room stat reports `ACTIVE` and includes an engine version.
- Sleeping yields `SLEEPING`.
- AI presence in an unconfigured room yields `AI_BLIND` rather than crashing.
- Room Conductor exposes a Bubble context provider while remaining internal-only and not a character slot.
- The e-PETE / voxel bridge regression suite preserves Bubble Stack routes while keeping unrelated runtime claims honest.

## What “used” means here

The evidence supports saying Bubble Stack is **implemented and wired into the PubCast host architecture**, with a tested API/state path and an optional PIKPC engine. The files do not prove that a live production 3D session is currently running Bubble Stack continuously. They prove the integration and regression behavior in code.

That distinction matters: “implemented and integrated” is supported; “currently operating in a live production scene” is not established by these documents alone.
